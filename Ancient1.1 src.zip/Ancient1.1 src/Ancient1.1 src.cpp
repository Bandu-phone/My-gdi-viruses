#include <windows.h>
#include <mmsystem.h>
#include <cmath>
#include <chrono>
#include <cstdlib>
#include <algorithm>
#include <vector>
#include <ctime>

#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif

#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")

const LPCWSTR AUDIO_FILES[] = {
    L"rave.wav",
    L"banger.wav",
    L"crazy.wav",
    L"solaris.wav",
    L"funky.wav",
    L"kaboom.wav",
    L"cool.wav",
    L"budgie.wav",
    L"final.wav",
    L"extra1.wav",
    L"extra2.wav",
    L"extra3.wav",
    L"extra4.wav",
    L"new_audio_1.wav", 
    L"new_audio_2.wav", 
    L"new_audio_3.wav", 
    L"new_audio_4.wav", 
    L"new_audio_5.wav", 
    L"new_audio_6.wav", 
    L"new_audio_7.wav", 
    L"new_audio_8.wav", 
    L"new_audio_9.wav", 
    L"new_audio_10.wav"
};
const int NUM_AUDIO_FILES = sizeof(AUDIO_FILES) / sizeof(AUDIO_FILES[0]);

#define STAGE_TIME_INTERVAL 20.0f
#define STAGE_COUNT 40

#define APP_TITLE L"𒈔 𒀭 𒆠 𒇽 لومات 𒎗 𒎩 𒎰 𒍸 𒍯 𒍾 𒌑 𒌋 𒌁 .exe"
#define MESSAGE_TEXT L"¿Do you want to run this gdi-malware? (GDI-ONLY)\n\n¡IMPORTANT! The only way to exit this virus is by pressing [ESC] or taskkilling it. It has 40 STAGES of 20 secs each one (13 MINUTES 20 SECONDS)"
int lastPlayedAudioIndex = -1; 


LPCWSTR GetRandomAudioFile() {
    int newIndex;
    do {
        newIndex = rand() % NUM_AUDIO_FILES;
    } while (newIndex == lastPlayedAudioIndex);

    lastPlayedAudioIndex = newIndex;
    return AUDIO_FILES[newIndex];
}

DWORD HSLToRGB(float h, float s, float l) {
    if (s == 0.0f) {
        BYTE gray = (BYTE)(l * 255.0f);
        return RGB(gray, gray, gray);
    }

    auto hue2rgb = [](float p, float q, float t) {
        if (t < 0) t += 1;
        if (t > 1) t -= 1;
        if (t < 1.0f / 6.0f) return p + (q - p) * 6.0f * t;
        if (t < 1.0f / 2.0f) return q;
        if (t < 2.0f / 3.0f) return p + (q - p) * (2.0f / 3.0f - t) * 6.0f;
        return p;
    };

    float q = l < 0.5f ? l * (1.0f + s) : l + s - l * s;
    float p = 2.0f * l - q;
    
    float r = hue2rgb(p, q, h + 1.0f / 3.0f);
    float g = hue2rgb(p, q, h);
    float b = hue2rgb(p, q, h - 1.0f / 3.0f);

    return RGB((BYTE)(r * 255.0f), (BYTE)(g * 255.0f), (BYTE)(b * 255.0f));
}

BYTE ColorWave(float position, float phase, float frequency) {
    return (BYTE)(std::sin(frequency * position + phase) * 127.5f + 127.5f);
}

float GetStageStartTime(int stageNumber) {
    if (stageNumber < 1 || stageNumber > STAGE_COUNT) return -1.0f;
    return (float)(stageNumber - 1) * STAGE_TIME_INTERVAL;
}

void RenderDesktopShader() {
    HDC hdcScreen = GetDC(NULL); 
    if (!hdcScreen) return;

    int screenWidth = GetSystemMetrics(SM_CXSCREEN);
    int screenHeight = GetSystemMetrics(SM_CYSCREEN);

    BITMAPINFO bmi = {0};
    bmi.bmiHeader.biSize = sizeof(BITMAPINFOHEADER);
    bmi.bmiHeader.biWidth = screenWidth;
    bmi.bmiHeader.biHeight = -screenHeight;
    bmi.bmiHeader.biPlanes = 1;
    bmi.bmiHeader.biBitCount = 32;
    bmi.bmiHeader.biCompression = BI_RGB;

    VOID* pvBits = NULL;
    HBITMAP hDIB = CreateDIBSection(hdcScreen, &bmi, DIB_RGB_COLORS, &pvBits, NULL, 0);
    if (!hDIB || !pvBits) {
        ReleaseDC(NULL, hdcScreen);
        return;
    }

    HDC hdcMem = CreateCompatibleDC(hdcScreen);
    HGDIOBJ hOldBitmap = SelectObject(hdcMem, hDIB);

    DWORD* pixels = (DWORD*)pvBits;

    auto startTime = std::chrono::high_resolution_clock::now();
    float time = 0.0f;
    bool running = true;
    int currentStage = 1;
    
    float cx = screenWidth / 2.0f;
    float cy = screenHeight / 2.0f;

    float speed = 0.5f; 
    float horizontalRange = screenWidth * 0.7f;
    float horizontalOffset = screenWidth * 0.15f;
  
    while (running) {
        if (GetAsyncKeyState(VK_ESCAPE) & 0x8000) {
            running = false;
        }

        auto currentTime = std::chrono::high_resolution_clock::now();
        std::chrono::duration<float> elapsed = currentTime - startTime;
        time = elapsed.count(); 
        
        int nextStage = 1;
        
        for (int i = STAGE_COUNT; i >= 2; --i) {
            if (time >= GetStageStartTime(i)) {
                nextStage = i;
                break;
            }
        }
        
        if (nextStage > currentStage) {
            currentStage = nextStage;
            PlaySoundW(NULL, NULL, 0);
            
            LPCWSTR audioFile = GetRandomAudioFile(); 
            
            if (audioFile) {
                PlaySoundW(audioFile, NULL, SND_FILENAME | SND_ASYNC | SND_NODEFAULT);
            }
        }
        
        bool isMouseActive = currentStage >= 3;
        bool isTremorActive = currentStage >= 3;
        bool isWindowCheckActive = currentStage >= 4;
        
        POINT mousePos = { (int)cx, (int)cy };
        if (isMouseActive) {
            GetCursorPos(&mousePos);
            ScreenToClient(NULL, &mousePos);
        }

        int shakeX = 0, shakeY = 0;
        if (isTremorActive) {
            shakeX = (rand() % 30) - 15; 
            shakeY = (rand() % 30) - 15;
        }

        RECT focusedWndRect = {0};
        bool isWindowFocused = false;
        if (isWindowCheckActive) {
            HWND focusedWnd = GetForegroundWindow();
            if (focusedWnd && focusedWnd != GetDesktopWindow() && IsWindowVisible(focusedWnd)) {
                GetWindowRect(focusedWnd, &focusedWndRect);
                isWindowFocused = true;
            }
        }

        // BUCLE DE MANIPULACIÓN DE PÍXELES DIRECTA
        for (int y = 0; y < screenHeight; ++y) {
            for (int x = 0; x < screenWidth; ++x) {
                int tremoloX = x + shakeX;
                int tremoloY = y + shakeY;

                if (tremoloX < 0 || tremoloX >= screenWidth || tremoloY < 0 || tremoloY >= screenHeight) {
                    pixels[x + y * screenWidth] = RGB(0, 0, 0);
                    continue;
                }
                
                int index = x + y * screenWidth;
                
                float r = 0.0f, g = 0.0f, b = 0.0f;
                float t_stage = time - GetStageStartTime(currentStage); 
                
                switch (currentStage) {
                    case 1: {
                        float dist = std::sqrt(std::pow(tremoloX - cx, 2) + std::pow(tremoloY - cy, 2)) / (screenWidth > screenHeight ? screenWidth : screenHeight);
                        
                        BYTE baseR = ColorWave(tremoloX / 50.0f, time * 1.5f + dist * 5.0f, 1.0f);
                        BYTE baseG = ColorWave(tremoloY / 50.0f, time * 2.0f + dist * 3.0f, 1.0f);
                        BYTE baseB = ColorWave((tremoloX + tremoloY) / 75.0f, time * 2.5f + dist * 7.0f, 1.0f);

                        BYTE xor_val = (BYTE)(((int)(time * 10.0f) * 16) ^ (tremoloX * 16) ^ (tremoloY * 16));
                        
                        r = (float)(baseR ^ xor_val);
                        g = (float)(baseG ^ (xor_val / 2));
                        b = (float)(baseB ^ (xor_val * 2));
                        break;
                    }
                    case 2: {
                        float coordX = (float)tremoloX / screenWidth;
                        float coordY = (float)tremoloY / screenHeight;
                        
                        float stripePattern = std::fmod(coordX * 15.0f + coordY * 10.0f - t_stage * 5.0f, 1.0f);
                        float hueShift = std::sin(t_stage / 2.0f);

                        float baseR_f = std::cos(stripePattern * 20.0f + hueShift * 2.0f) * 0.5f + 0.5f;
                        float baseG_f = std::sin(stripePattern * 20.0f + hueShift * 4.0f) * 0.5f + 0.5f;
                        float baseB_f = std::cos(stripePattern * 20.0f + hueShift * 6.0f) * 0.5f + 0.5f;

                        BYTE finalR = (BYTE)(baseR_f * 255);
                        BYTE finalG = (BYTE)(baseG_f * 255);
                        BYTE finalB = (BYTE)(baseB_f * 255);
                        
                        BYTE xor_val_2 = (BYTE)(((int)(t_stage * 20.0f) * 8) ^ (tremoloY * 10) ^ (tremoloX / 10));

                        r = (float)(finalR ^ xor_val_2);
                        g = (float)(finalG ^ (xor_val_2 / 2));
                        b = (float)(finalB ^ (xor_val_2 * 2));

                        float totalDistance = horizontalRange;
                        float t_bounce = std::fmod(t_stage * speed / totalDistance, 2.0f); 
                        float posNormalized = (t_bounce < 1.0f) ? t_bounce : (2.0f - t_bounce);
                        float triangleCenterX = posNormalized * horizontalRange + horizontalOffset;
                        float triangleCenterY = screenHeight * 0.5f;
                        float triangleHeight = screenHeight * 0.3f;
                        float triangleBaseHalf = triangleHeight * 0.866f / 2.0f;
                        
                        float x_rel = std::abs(tremoloX - triangleCenterX);
                        float halfHeightAtX = triangleHeight / 2.0f * (1.0f - x_rel / triangleBaseHalf);

                        bool insideShape = (x_rel < triangleBaseHalf) && (std::abs(tremoloY - triangleCenterY) < halfHeightAtX);
                                           
                        if (insideShape) {
                            float gradientPos = (tremoloX - (triangleCenterX - triangleBaseHalf)) / (triangleBaseHalf * 2.0f);
                            BYTE gradR = ColorWave(gradientPos * 6.0f, t_stage * 1.5f, 1.0f);
                            BYTE gradG = ColorWave(gradientPos * 6.0f, t_stage * 1.5f + 2.0f, 1.0f);
                            BYTE gradB = ColorWave(gradientPos * 6.0f, t_stage * 1.5f + 4.0f, 1.0f);
                            r = (float)gradR;
                            g = (float)gradG;
                            b = (float)gradB;
                        }
                        break;
                    }
                    case 3: {
                        float centerX = (float)mousePos.x;
                        float centerY = (float)mousePos.y;

                        float deltaX = tremoloX - centerX;
                        float deltaY = tremoloY - centerY;
                        float angle = std::atan2(deltaY, deltaX); 
                        float dist = std::sqrt(deltaX * deltaX + deltaY * deltaY);

                        float hue = std::fmod(angle / (2.0f * M_PI) + dist * 0.001f - t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f; 

                        float lum = 0.5f + std::cos(dist * 0.01f + t_stage * 5.0f) * 0.1f; 
                        float sat = 0.9f; 

                        DWORD spiralColor = HSLToRGB(hue, sat, lum);
                        
                        float mouseDist = std::sqrt(std::pow(tremoloX - mousePos.x, 2) + std::pow(tremoloY - mousePos.y, 2));
                        float distortionFactor = std::max(0.0f, 1.0f - mouseDist / 100.0f); 

                        float blink = std::sin(t_stage * 30.0f);
                        BYTE flashR = (BYTE)(blink * distortionFactor * 255.0f);

                        float alpha = 0.7f; 
                        float invAlpha = 1.0f - alpha;
                        
                        BYTE baseBg = (BYTE)(10 + (rand() % 50)); 

                        r = (GetRValue(spiralColor) * alpha + baseBg * invAlpha) + flashR; 
                        g = (GetGValue(spiralColor) * alpha + baseBg * invAlpha);
                        b = (GetBValue(spiralColor) * alpha + baseBg * invAlpha);
                        break;
                    }
                    case 4: {
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;

                        float dx = normalizedX - 0.5f;
                        float dy = normalizedY - 0.5f;
                        
                        float angle = std::atan2(dy, dx);
                        float dist = std::sqrt(dx * dx + dy * dy);

                        float rotationSpeed = t_stage * 0.5f;
                        float zoomFactor = 0.5f + std::sin(t_stage * 0.3f) * 0.2f;

                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 10.0f)); 
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 5.0f + t_stage * 1.5f) * 0.1f);
                        
                        float sampleX = std::fmod(modulatedDist / zoomFactor * 20.0f * std::cos(rotatedAngle), 1.0f);
                        float sampleY = std::fmod(modulatedDist / zoomFactor * 20.0f * std::sin(rotatedAngle), 1.0f);
                        
                        if (sampleX < 0) sampleX += 1.0f;
                        if (sampleY < 0) sampleY += 1.0f;

                        BYTE baseR = ColorWave(sampleX * 10.0f, t_stage * 3.0f, 1.0f);
                        BYTE baseG = ColorWave(sampleY * 10.0f, t_stage * 2.5f, 1.0f);
                        BYTE baseB = ColorWave((sampleX + sampleY) * 5.0f, t_stage * 3.5f, 1.0f);

                        BYTE complexXor = (BYTE)(((int)(t_stage * 5.0f) * 16) ^ (int)(modulatedDist * 1000.0f));
                        
                        r = (float)(baseR ^ complexXor);
                        g = (float)(baseG ^ (complexXor / 2));
                        b = (float)(baseB ^ (complexXor * 2));
                        
                        if (isWindowFocused) 
                        {
                            if (tremoloX >= focusedWndRect.left && tremoloX < focusedWndRect.right &&
                                tremoloY >= focusedWndRect.top && tremoloY < focusedWndRect.bottom) 
                            {
                                float wndX = (float)(tremoloX - focusedWndRect.left) / (focusedWndRect.right - focusedWndRect.left);
                                float wndY = (float)(tremoloY - focusedWndRect.top) / (focusedWndRect.bottom - focusedWndRect.top);
                                
                                float hue = std::fmod(wndX * 0.5f + wndY * 0.5f - t_stage * 0.4f + std::sin(t_stage * 2.0f) * 0.1f, 1.0f);
                                if (hue < 0) hue += 1.0f;
                                
                                DWORD rainbowColor = HSLToRGB(hue, 1.0f, 0.5f);
                                
                                float blendFactor = 0.5f; 
                                float invBlendFactor = 1.0f - blendFactor;
                                
                                r = (r * invBlendFactor) + (GetRValue(rainbowColor) * blendFactor);
                                g = (g * invBlendFactor) + (GetGValue(rainbowColor) * blendFactor);
                                b = (b * invBlendFactor) + (GetBValue(rainbowColor) * blendFactor);
                            }
                        }
                        break;
                    }
                    case 5: {
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;

                        float dx = normalizedX - 0.5f;
                        float dy = normalizedY - 0.5f;
                        
                        float angle = std::atan2(dy, dx);
                        float dist = std::sqrt(dx * dx + dy * dy);

                        float rotationSpeed = t_stage * 0.8f;
                        float zoomFactor = 0.2f + std::sin(t_stage * 0.7f) * 0.15f;

                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 15.0f));
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 7.0f + t_stage * 2.0f) * 0.2f);
                        
                        float sampleX = std::fmod(modulatedDist / zoomFactor * 30.0f * std::cos(rotatedAngle), 1.0f);
                        float sampleY = std::fmod(modulatedDist / zoomFactor * 30.0f * std::sin(rotatedAngle), 1.0f);
                        
                        if (sampleX < 0) sampleX += 1.0f;
                        if (sampleY < 0) sampleY += 1.0f;

                        BYTE baseR = ColorWave(sampleX * 10.0f, t_stage * 4.0f, 1.0f);
                        BYTE baseG = ColorWave(sampleY * 10.0f, t_stage * 3.5f, 1.0f);
                        BYTE baseB = ColorWave((sampleX + sampleY) * 5.0f, t_stage * 4.5f, 1.0f);

                        BYTE xor_modulation = (BYTE)(((int)(time * 15.0f) * 8) ^ (tremoloX * 8) ^ (tremoloY * 8));

                        r = (float)(baseR ^ xor_modulation);
                        g = (float)(baseG ^ (xor_modulation / 2));
                        b = (float)(baseB ^ (xor_modulation * 2));
                        
                        float mouseDist = std::sqrt(std::pow(tremoloX - mousePos.x, 2) + std::pow(tremoloY - mousePos.y, 2));
                        float distortionFactor = std::max(0.0f, 1.0f - mouseDist / 80.0f);

                        float blink = std::sin(t_stage * 40.0f);
                        BYTE flashR = (BYTE)(blink * distortionFactor * 255.0f);
                        r += flashR; 
                        
                        if (isWindowFocused) 
                        {
                            if (tremoloX >= focusedWndRect.left && tremoloX < focusedWndRect.right &&
                                tremoloY >= focusedWndRect.top && tremoloY < focusedWndRect.bottom) 
                            {
                                float wndX = (float)(tremoloX - focusedWndRect.left) / (focusedWndRect.right - focusedWndRect.left);
                                float wndY = (float)(tremoloY - focusedWndRect.top) / (focusedWndRect.bottom - focusedWndRect.top);
                                
                                float hue = std::fmod(wndX * 0.8f + wndY * 0.8f - t_stage * 0.6f + std::sin(t_stage * 3.0f) * 0.2f, 1.0f);
                                if (hue < 0) hue += 1.0f;
                                
                                DWORD rainbowColor = HSLToRGB(hue, 1.0f, 0.5f);
                                
                                float blendFactor = 0.5f; 
                                float invBlendFactor = 1.0f - blendFactor;
                                
                                r = (r * invBlendFactor) + (GetRValue(rainbowColor) * blendFactor);
                                g = (g * invBlendFactor) + (GetGValue(rainbowColor) * blendFactor);
                                b = (b * invBlendFactor) + (GetBValue(rainbowColor) * blendFactor);
                            }
                        }
                        break;
                    }
                    case 6: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;
                        
                        float offset = std::sin(u * 20.0f + t_stage * 3.0f) * 0.05f;
                        u += offset;
                        v += std::cos(v * 15.0f + t_stage * 2.0f) * 0.08f;
                        
                        float hue = std::fmod(u + v + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 0.8f, 0.5f);
                        
                        BYTE xor_val = (BYTE)(((int)(time * 12.0f) * 8) ^ (tremoloX % 100) ^ (tremoloY % 100));

                        r = (float)(GetRValue(color) ^ xor_val);
                        g = (float)(GetGValue(color) ^ (xor_val / 2));
                        b = (float)(GetBValue(color) ^ (xor_val * 2));
                        break;
                    }
                    case 7: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                        float plasma = std::sin(dist * 50.0f + t_stage * 5.0f) + 
                                       std::cos(angle * 10.0f + t_stage * 2.0f);

                        float hue = std::fmod(plasma / 2.0f + t_stage * 0.05f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        int offsetX = (int)(std::cos(t_stage) * 100.0f * dist);
                        int offsetY = (int)(std::sin(t_stage) * 100.0f * dist);
                        
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        
                        r *= (1.0f + std::sin((tremoloX + offsetX) / 50.0f) * 0.2f);
                        g *= (1.0f + std::cos((tremoloY + offsetY) / 50.0f) * 0.2f);
                        break;
                    }
                    case 8: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        
                        float zoom = std::fmod(t_stage * 0.5f, 2.0f);
                        float speedFactor = 10.0f / (zoom * 5.0f + 1.0f);

                        float rotatedX = normalizedX * std::cos(t_stage * 1.5f) - normalizedY * std::sin(t_stage * 1.5f);
                        float rotatedY = normalizedX * std::sin(t_stage * 1.5f) + normalizedY * std::cos(t_stage * 1.5f);
                        
                        float u = std::fmod(rotatedX * speedFactor * 50.0f, 1.0f);
                        float v = std::fmod(rotatedY * speedFactor * 50.0f, 1.0f);
                        
                        float colorVal = std::sin(u * 2.0f * M_PI) * std::cos(v * 2.0f * M_PI);
                        float hue = std::fmod(colorVal * 0.5f + 0.5f + t_stage * 0.15f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::cos(t_stage * 10.0f));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 9: {
                        int numColumns = 64;
                        float colWidth = (float)screenWidth / numColumns;
                        int colIndex = (int)(tremoloX / colWidth);
                        float colTime = (float)colIndex / numColumns;
                        
                        float pulse = std::abs(std::sin(t_stage * 5.0f + colTime * 5.0f));
                        float maxHeight = screenHeight * 0.5f;
                        float currentHeight = maxHeight * pulse;
                        
                        if (std::abs(tremoloY - cy) < currentHeight) {
                            float intensity = 1.0f - std::abs(tremoloY - cy) / currentHeight;
                            float hue = std::fmod(colTime * 0.8f + t_stage * 0.2f, 1.0f);
                            if (hue < 0) hue += 1.0f;
                            
                            DWORD color = HSLToRGB(hue, 1.0f, intensity * 0.8f + 0.2f);
                            r = GetRValue(color);
                            g = GetGValue(color);
                            b = GetBValue(color);
                        } else {
                            float background = std::fmod(tremoloX / 20.0f + t_stage * 0.1f, 1.0f);
                            r = g = b = (background < 0.5f) ? 50.0f : 0.0f;
                        }
                        break;
                    }
                    case 10: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                        float rotation = t_stage * 5.0f;
                        
                        float pattern = std::fmod(dist * 100.0f + angle * 10.0f + rotation, 1.0f);
                        
                        float hue = std::fmod(pattern + t_stage * 0.3f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + dist * 0.5f);
                        
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        
                       BYTE xor_val = (BYTE)(((int)(t_stage * 30.0f) * 4) ^ (tremoloY * 4));

                        r = (float)(((int)r) ^ xor_val); 
                        g = (float)(((int)g) ^ xor_val); 
                        b = (float)(((int)b) ^ xor_val);
                        break;
                    }
                    case 11: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float mouseInfluence = 0.1f;
                        float mouseDx = (float)mousePos.x / screenWidth - 0.5f;
                        float mouseDy = (float)mousePos.y / screenHeight - 0.5f;
                        
                        u += std::sin(v * 20.0f) * mouseDx * mouseInfluence;
                        v += std::cos(u * 15.0f) * mouseDy * mouseInfluence;

                        float stripePattern = std::fmod(u * 10.0f + v * 10.0f + t_stage * 4.0f, 1.0f);
                        
                        float hue = std::fmod(stripePattern + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 0.9f, 0.5f + 0.5f * std::sin(stripePattern * 2.0f * M_PI));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 12: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;
                        
                        float grid = std::fmod(u * 10.0f, 1.0f) > 0.5f ? 1.0f : 0.0f;
                        grid += std::fmod(v * 10.0f, 1.0f) > 0.5f ? 1.0f : 0.0f;
                        
                        float refractX = u + std::sin(t_stage * 3.0f + grid * 10.0f) * 0.05f;
                        float refractY = v + std::cos(t_stage * 2.5f + grid * 15.0f) * 0.05f;
                        
                        float hue = std::fmod(refractX + refractY * 0.5f + t_stage * 0.08f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        if (std::fmod(tremoloX + tremoloY, 50.0f) < 5.0f && std::sin(t_stage * 10.0f) > 0.0f) {
                            r = 255.0f - GetRValue(color);
                            g = 255.0f - GetGValue(color);
                            b = 255.0f - GetBValue(color);
                        } else {
                            r = GetRValue(color);
                            g = GetGValue(color);
                            b = GetBValue(color);
                        }
                        break;
                    }
                    case 13: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float vortexCenterX = std::sin(t_stage * 0.5f) * 0.3f;
                        float vortexCenterY = std::cos(t_stage * 0.4f) * 0.3f;
                        
                        float dx = normalizedX - vortexCenterX;
                        float dy = normalizedY - vortexCenterY;

                        float angle = std::atan2(dy, dx);
                        float dist = std::sqrt(dx * dx + dy * dy);

                        float warpAngle = angle + (1.0f / (dist * 10.0f)) * 0.1f + t_stage * 0.5f;
                        float warpedDist = dist * (1.0f + std::sin(dist * 50.0f) * 0.05f);

                        float hue = std::fmod(warpAngle / (2.0f * M_PI) + warpedDist * 10.0f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        if (isWindowFocused) {
                            if (tremoloX >= focusedWndRect.left && tremoloX < focusedWndRect.right && tremoloY >= focusedWndRect.top && tremoloY < focusedWndRect.bottom) {
                                float pulse = std::abs(std::sin(t_stage * 10.0f));
                                r = std::min(255.0f, GetRValue(color) * (1.0f + pulse * 0.5f));
                                g = std::min(255.0f, GetGValue(color) * (1.0f + pulse * 0.5f));
                                b = std::min(255.0f, GetBValue(color) * (1.0f + pulse * 0.5f));
                            } else {
                                r = GetRValue(color); g = GetGValue(color); b = GetBValue(color);
                            }
                        } else {
                            r = GetRValue(color); g = GetGValue(color); b = GetBValue(color);
                        }
                        break;
                    }
                    case 14: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float noise = std::cos(u * 30.0f + t_stage) * std::sin(v * 20.0f + t_stage * 0.5f);
                        
                        float hue = std::fmod(noise * 0.5f + 0.5f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        float lum = 0.5f + noise * 0.2f + 0.3f * std::sin(t_stage * 10.0f);
                        
                        DWORD color = HSLToRGB(hue, 1.0f, lum);

                        BYTE xor_val = (BYTE)(((int)(t_stage * 20.0f) * 16) ^ (tremoloX % 200) ^ (tremoloY % 200));

                        r = (float)(GetRValue(color) ^ xor_val);
                        g = (float)(GetGValue(color) ^ (xor_val / 2));
                        b = (float)(GetBValue(color) ^ (xor_val * 2));
                        break;
                    }
                    case 15: {
                        float u = (float)tremoloX / 100.0f;
                        float v = (float)tremoloY / 100.0f;
                        
                        float shift = t_stage * 2.0f;
                        
                        bool isBlack = ((int)(u + shift) % 2) == ((int)(v + shift * 0.5f) % 2);

                        if (isBlack) {
                            r = g = b = 255.0f;
                        } else {
                            float hue = std::fmod(u / 10.0f + v / 10.0f + t_stage * 0.1f, 1.0f);
                            if (hue < 0) hue += 1.0f;
                            DWORD color = HSLToRGB(hue, 0.8f, 0.5f);
                            r = GetRValue(color);
                            g = GetGValue(color);
                            b = GetBValue(color);
                        }
                        
                        if (std::fmod(t_stage, 0.5f) < 0.1f) {
                            r = (float)(rand() % 256);
                            g = (float)(rand() % 256);
                            b = (float)(rand() % 256);
                        }
                        break;
                    }
                    case 16: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        
                        float angle = t_stage * 0.5f;
                        
                        float x3 = normalizedX * std::cos(angle) + normalizedY * std::sin(angle);
                        float y3 = normalizedY * std::cos(angle) - normalizedX * std::sin(angle);
                        float z3 = std::sin(t_stage * 0.2f) * 0.1f;

                        float depth = 1.0f / (1.0f - z3);
                        float px = x3 * depth;
                        float py = y3 * depth;
                        
                        float lineX = std::abs(std::cos(px * 50.0f)) * 50.0f;
                        float lineY = std::abs(std::sin(py * 50.0f)) * 50.0f;
                        
                        float intensity = std::min(1.0f, (lineX + lineY) / 10.0f);

                        float hue = std::fmod(px * 0.5f + py * 0.5f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, intensity, 0.5f);
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 17: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float distortX = std::sin(u * 10.0f + t_stage * 2.0f) * 0.05f;
                        float distortY = std::cos(v * 15.0f + t_stage * 1.5f) * 0.05f;

                        float blobCenterU = 0.5f + std::sin(t_stage * 0.1f) * 0.2f;
                        float blobCenterV = 0.5f + std::cos(t_stage * 0.15f) * 0.2f;

                        float distToCenter = std::sqrt(std::pow(u + distortX - blobCenterU, 2) + std::pow(v + distortY - blobCenterV, 2));

                        float blobPulse = 0.5f + 0.5f * std::sin(t_stage * 8.0f);
                        
                        float hue = std::fmod(distToCenter * 5.0f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        float sat = 1.0f;
                        float lum = 0.5f + (1.0f - distToCenter * 2.0f) * blobPulse * 0.4f;
                        lum = std::min(1.0f, std::max(0.0f, lum));

                        DWORD color = HSLToRGB(hue, sat, lum);
                        r = GetRValue(color); g = GetGValue(color); b = GetBValue(color);
                        break;
                    }
                    case 18: {
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;
                        
                        float gridR = std::fmod(normalizedX * 10.0f, 1.0f) * 255.0f;
                        float gridG = std::fmod(normalizedY * 10.0f, 1.0f) * 255.0f;
                        float gridB = std::fmod((normalizedX + normalizedY) * 5.0f, 1.0f) * 255.0f;
                        
                        float deltaX = normalizedX - (float)mousePos.x / screenWidth;
                        float deltaY = normalizedY - (float)mousePos.y / screenHeight;
                        float angle = std::atan2(deltaY, deltaX); 
                        float dist = std::sqrt(deltaX * deltaX + deltaY * deltaY);

                        float hue = std::fmod(angle / (2.0f * M_PI) + dist * 5.0f - t_stage * 0.2f, 1.0f);
                        if (hue < 0) hue += 1.0f; 

                        DWORD spiralColor = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        float mixFactor = 0.5f + 0.5f * std::sin(t_stage * 5.0f);
                        
                        r = gridR * (1.0f - mixFactor) + GetRValue(spiralColor) * mixFactor;
                        g = gridG * (1.0f - mixFactor) + GetGValue(spiralColor) * mixFactor;
                        b = gridB * (1.0f - mixFactor) + GetBValue(spiralColor) * mixFactor;
                        break;
                    }
                    case 19: {
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;
                        
                        float invX = 1.0f - normalizedX;
                        float invY = 1.0f - normalizedY;
                        
                        float u = (std::sin(t_stage * 0.1f) > 0.0f) ? normalizedX : invX;
                        float v = (std::cos(t_stage * 0.1f) > 0.0f) ? normalizedY : invY;
                        
                        float hue = std::fmod(u * 0.5f + v * 0.5f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD baseColor = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        r = GetRValue(baseColor);
                        g = GetGValue(baseColor);
                        b = GetBValue(baseColor);

                        if (std::sin(t_stage * 15.0f) > 0.5f) {
                            r = 255.0f - r;
                            g = 255.0f - g;
                            b = 255.0f - b;
                        }
                        
                        if (isWindowFocused) 
                        {
                            if (tremoloX >= focusedWndRect.left && tremoloX < focusedWndRect.right &&
                                tremoloY >= focusedWndRect.top && tremoloY < focusedWndRect.bottom) 
                            {
                                float redPulse = 0.7f + 0.3f * std::sin(t_stage * 20.0f);
                                r = std::min(255.0f, r * redPulse);
                                g = std::min(255.0f, g * 0.5f);
                                b = std::min(255.0f, b * 0.5f);
                            }
                        }
                        break;
                    }
                    case 20: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        float t_end = t_stage; 

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                        float rotationSpeed = t_end * 1.5f;
                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 20.0f)); 
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 10.0f + t_end * 3.0f) * 0.3f);
                        
                        float sampleX = std::fmod(modulatedDist * 50.0f * std::cos(rotatedAngle), 1.0f); 
                        float sampleY = std::fmod(modulatedDist * 50.0f * std::sin(rotatedAngle), 1.0f);
                        if (sampleX < 0) sampleX += 1.0f;
                        if (sampleY < 0) sampleY += 1.0f;

                        BYTE baseR = ColorWave(sampleX * 10.0f, t_end * 6.0f, 1.0f);
                        BYTE baseG = ColorWave(sampleY * 10.0f, t_end * 5.0f, 1.0f);
                        BYTE baseB = ColorWave((sampleX + sampleY) * 5.0f, t_end * 7.0f, 1.0f);
                        BYTE xor_val = (BYTE)(((int)(time * 20.0f) * 16) ^ (tremoloX * 20) ^ (tremoloY * 20));

                        r = (float)(baseR ^ xor_val);
                        g = (float)(baseG ^ (xor_val / 2));
                        b = (float)(baseB ^ (xor_val * 2));
                        
                        float wipeFactor = (t_end > 15.0f) ? (t_end - 15.0f) / 5.0f : 0.0f;
                        wipeFactor = std::min(1.0f, wipeFactor);

                        r = r * (1.0f - wipeFactor) + 255.0f * wipeFactor;
                        g = g * (1.0f - wipeFactor) + 255.0f * wipeFactor;
                        b = b * (1.0f - wipeFactor) + 255.0f * wipeFactor;

                        break;
                    }
                    case 21: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        
                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                        float modAngle = std::fmod(angle, 2.0f * M_PI / 6.0f);
                        if (modAngle < 0) modAngle += 2.0f * M_PI / 6.0f;
                        
                        float refAngle = std::abs(modAngle - M_PI / 6.0f); 

                        float rotatedAngle = refAngle + t_stage * 0.8f;
                        float zoomedDist = dist * (1.0f + std::sin(t_stage * 0.5f) * 0.2f) * 10.0f;

                        float hue = std::fmod(rotatedAngle / (2.0f * M_PI) + zoomedDist * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::cos(zoomedDist));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 22: {
                        int blockSize = 30;
                        int blockX = tremoloX / blockSize;
                        int blockY = tremoloY / blockSize;
                        
                        int pattern = (int)std::fmod(t_stage * 10.0f + blockX + blockY, 2.0f);

                        if (pattern == 0) {
                            float pulse = std::abs(std::sin(t_stage * 15.0f));
                            r = 0.0f;
                            g = 255.0f * pulse;
                            b = 255.0f;
                        } else {
                            float pulse = std::abs(std::cos(t_stage * 15.0f));
                            r = 255.0f;
                            g = 0.0f;
                            b = 255.0f * pulse;
                        }
                        break;
                    }
                    case 23: {
                        float deltaX = tremoloX - cx;
                        float deltaY = tremoloY - cy;
                        float dist = std::sqrt(deltaX * deltaX + deltaY * deltaY);
                        
                        float ringFreq = std::fmod(dist * 0.2f - t_stage * 4.0f, 10.0f);
                        
                        float brightness = std::abs(std::sin(ringFreq * M_PI / 5.0f));
                        
                        float angle = std::atan2(deltaY, deltaX);
                        float hue = std::fmod(angle / (2.0f * M_PI) + t_stage * 0.05f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, 0.2f + brightness * 0.6f);
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 24: {
                        float centerX = (float)mousePos.x;
                        float centerY = (float)mousePos.y;

                        float dist = std::sqrt(std::pow(tremoloX - centerX, 2) + std::pow(tremoloY - centerY, 2));

                        float energy = 1.0f - std::min(1.0f, dist / 200.0f);
                        energy *= (0.5f + 0.5f * std::sin(t_stage * 15.0f));

                        float hue = std::fmod(dist * 0.005f + t_stage * 0.2f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, energy * 0.8f);
                        r = GetRValue(color); g = GetGValue(color); b = GetBValue(color);

                        if (dist > 200.0f) {
                            BYTE xor_val = (BYTE)(((int)(time * 10.0f) * 8) ^ (tremoloX / 32) ^ (tremoloY / 32));
                            r = (float)(((int)r) ^ xor_val);
                            g = (float)(((int)g) ^ xor_val);
                            b = (float)(((int)b) ^ xor_val);
                        }
                        break;
                    }
                    case 25: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                        float rotation = t_stage * 7.0f;
                        
                        float pattern = std::fmod(angle * 10.0f + dist * 50.0f + rotation, 2.0f);
                        
                        float hue = std::fmod(pattern / 2.0f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::sin(pattern * M_PI));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 26: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        if (isWindowFocused) {
                            if (tremoloX >= focusedWndRect.left && tremoloX < focusedWndRect.right &&
                                tremoloY >= focusedWndRect.top && tremoloY < focusedWndRect.bottom) {
                                
                                float wndX = (float)(tremoloX - focusedWndRect.left) / (focusedWndRect.right - focusedWndRect.left);
                                float wndY = (float)(tremoloY - focusedWndRect.top) / (focusedWndRect.bottom - focusedWndRect.top);

                                float hue = std::fmod(wndX * 5.0f + wndY * 5.0f + t_stage * 1.0f, 1.0f);
                                if (hue < 0) hue += 1.0f;
                                
                                DWORD rainbowColor = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::sin(t_stage * 10.0f));

                                r = GetRValue(rainbowColor);
                                g = GetGValue(rainbowColor);
                                b = GetBValue(rainbowColor);

                                if (rand() % 100 < 5) {
                                    r = 255.0f - r;
                                    g = 255.0f - g;
                                    b = 255.0f - b;
                                }
                            } else {
                                BYTE xor_val = (BYTE)(((int)(time * 5.0f) * 16) ^ (tremoloX / 50));
                                r = g = b = (float)(100 ^ xor_val);
                            }
                        } else {
                            float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                            float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                            float angle = std::atan2(normalizedY, normalizedX);
                            float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);

                            float rotationSpeed = t_stage * 1.5f; 
                            float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 20.0f)); 
                            
                            BYTE xor_val = (BYTE)(((int)(time * 20.0f) * 16) ^ (tremoloX * 20) ^ (tremoloY * 20));

                            r = (float)(ColorWave(angle, t_stage * 5.0f, 1.0f) ^ xor_val);
                            g = (float)(ColorWave(dist, t_stage * 6.0f, 1.0f) ^ (xor_val / 2));
                            b = (float)(ColorWave(angle * dist, t_stage * 7.0f, 1.0f) ^ (xor_val * 2));
                        }
                        break;
                    }
                    case 27: {
                        int gridX = 4;
                        int gridY = 4;
                        float cellWidth = (float)screenWidth / gridX;
                        float cellHeight = (float)screenHeight / gridY;
                        
                        int cellCol = (int)(tremoloX / cellWidth);
                        int cellRow = (int)(tremoloY / cellHeight);

                        float relX = (tremoloX - cellCol * cellWidth) / cellWidth;
                        float relY = (tremoloY - cellRow * cellHeight) / cellHeight;

                        float u = (cellCol % 2 == 0) ? relX : 1.0f - relX;
                        float v = (cellRow % 2 == 0) ? relY : 1.0f - relY;
                        
                        float hue = std::fmod(u * 5.0f + v * 5.0f + t_stage * 0.3f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);
                        r = GetRValue(color); g = GetGValue(color); b = GetBValue(color);
                        
                        if (std::fmod(t_stage * 2.0f, 1.0f) < 0.1f) {
                            if (rand() % 16 == (cellRow * gridX + cellCol)) {
                                r = g = b = 255.0f;
                            }
                        }
                        break;
                    }
                    case 28: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float linePosNormalized = std::fmod(t_stage * 0.2f, 2.0f);
                        float linePos = (linePosNormalized < 1.0f) ? linePosNormalized : (2.0f - linePosNormalized);
                        
                        float lineY = screenHeight * linePos;
                        float distToLine = std::abs(tremoloY - lineY);
                        float brightness = std::exp(-distToLine * distToLine / 2000.0f); 

                        float hue = std::fmod(u + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD baseColor = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        r = GetRValue(baseColor) * (1.0f + brightness * 1.0f);
                        g = GetGValue(baseColor) * (1.0f + brightness * 1.0f);
                        b = GetBValue(baseColor) * (1.0f + brightness * 1.0f);

                        r = std::max(r, 50.0f);
                        g = std::max(g, 50.0f);
                        b = std::max(b, 50.0f);
                        break;
                    }
                    case 29: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float vortexCenterX = std::sin(t_stage * 0.4f) * 0.2f;
                        float vortexCenterY = std::cos(t_stage * 0.3f) * 0.2f;
                        
                        float dx = normalizedX - vortexCenterX;
                        float dy = normalizedY - vortexCenterY;

                        float angle = std::atan2(dy, dx);
                        float dist = std::sqrt(dx * dx + dy * dy);

                        float rotationSpeed = t_stage * 1.0f;
                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 20.0f)); 
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 8.0f + t_stage * 2.5f) * 0.25f);

                        float hue = std::fmod(rotatedAngle / (2.0f * M_PI) + modulatedDist * 15.0f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::sin(t_stage * 10.0f));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        
                        float mouseDist = std::sqrt(std::pow(tremoloX - mousePos.x, 2) + std::pow(tremoloY - mousePos.y, 2));
                        float distortionFactor = std::max(0.0f, 1.0f - mouseDist / 120.0f); 

                        float blink = std::sin(t_stage * 25.0f);
                        BYTE flashR = (BYTE)(blink * distortionFactor * 255.0f);
                        r += flashR; 
                        
                        break;
                    }
                    case 30: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        float t_end = t_stage; 

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);
                        float rotationSpeed = t_end * 2.0f; 
                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 30.0f)); 
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 15.0f + t_end * 4.0f) * 0.5f);
                        
                        float sampleX = std::fmod(modulatedDist * 60.0f * std::cos(rotatedAngle), 1.0f); 
                        float sampleY = std::fmod(modulatedDist * 60.0f * std::sin(rotatedAngle), 1.0f);
                        if (sampleX < 0) sampleX += 1.0f;
                        if (sampleY < 0) sampleY += 1.0f;

                        BYTE baseR = ColorWave(sampleX * 10.0f, t_end * 8.0f, 1.0f);
                        BYTE baseG = ColorWave(sampleY * 10.0f, t_end * 7.0f, 1.0f);
                        BYTE baseB = ColorWave((sampleX + sampleY) * 5.0f, t_end * 9.0f, 1.0f);

                        r = (float)baseR;
                        g = (float)baseG;
                        b = (float)baseB;
                        
                        float fadeFactor = (t_end > 15.0f) ? (t_end - 15.0f) / 5.0f : 0.0f;
                        fadeFactor = std::min(1.0f, fadeFactor);

                        r = r * (1.0f - fadeFactor);
                        g = g * (1.0f - fadeFactor);
                        b = b * (1.0f - fadeFactor);
                        
                        if (t_end >= 20.0f) {
                            running = false;
                        }

                        break;
                    }
                    case 31: { 
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float meltX = u + std::sin(v * 30.0f + t_stage * 1.5f) * 0.03f;
                        float meltY = v + std::cos(u * 25.0f + t_stage * 2.0f) * 0.04f;

                        float hue = std::fmod(meltX + meltY + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        float sat = 0.9f;
                        float lum = 0.5f + std::sin(meltX * 10.0f + meltY * 10.0f) * 0.1f;
                        
                        DWORD color = HSLToRGB(hue, sat, lum);
                        
                        BYTE xor_val = (BYTE)(((int)(time * 10.0f) * 8) ^ (tremoloX / 64) ^ (tremoloY / 64));

                        r = (float)(GetRValue(color) ^ xor_val);
                        g = (float)(GetGValue(color) ^ (xor_val / 2));
                        b = (float)(GetBValue(color) ^ (xor_val * 2));
                        
                        break;
                    }
                    case 32: { 
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;

                        float dx = normalizedX;
                        float dy = normalizedY;

                        float angle = std::atan2(dy, dx);
                        float dist = std::sqrt(dx * dx + dy * dy);

                        float rotation = t_stage * 10.0f; 
                        float rotatedAngle = angle + rotation / (dist * 5.0f + 0.1f);
                        
                        float hue = std::fmod(rotatedAngle / (2.0f * M_PI) + dist * 50.0f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::sin(dist * 100.0f + t_stage * 5.0f));
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        break;
                    }
                    case 33: { 
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;
                        
                        int column = tremoloX / 10;
                        float columnOffset = std::sin(column * 0.5f + t_stage * 3.0f) * 0.5f; 

                        float line = std::fmod(v * 50.0f + columnOffset + t_stage * 2.0f, 1.0f);
                        
                        float hue = std::fmod(column * 0.01f + t_stage * 0.05f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD baseColor = HSLToRGB(hue, 1.0f, 0.2f + line * 0.6f);
                        
                        BYTE xor_flicker = (rand() % 2 == 0) ? (BYTE)(((int)(t_stage * 100.0f) * 1) ^ (column * 10)) : 0;
                        
                        r = (float)(GetRValue(baseColor) ^ xor_flicker);
                        g = (float)(GetGValue(baseColor) ^ xor_flicker);
                        b = (float)(GetBValue(baseColor) ^ xor_flicker);
                        break;
                    }
                    case 34: { 
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;
                        
                        float mouseNormX = (float)mousePos.x / screenWidth;
                        float mouseNormY = (float)mousePos.y / screenHeight;

                        float dist = std::sqrt(std::pow(normalizedX - mouseNormX, 2) + std::pow(normalizedY - mouseNormY, 2));
                        float influence = 1.0f - std::min(1.0f, dist * 5.0f); 

                        float hue = std::fmod(normalizedX * 0.5f + normalizedY * 0.5f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD baseColor = HSLToRGB(hue, 1.0f, 0.5f);
                        
                        float invFactor = (0.5f + 0.5f * std::sin(t_stage * 10.0f)) * influence;
                        
                        r = GetRValue(baseColor);
                        g = GetGValue(baseColor);
                        b = GetBValue(baseColor);

                        r = r * (1.0f - invFactor) + (255.0f - r) * invFactor;
                        g = g * (1.0f - invFactor) + (255.0f - g) * invFactor;
                        b = b * (1.0f - invFactor) + (255.0f - b) * invFactor;

                        break;
                    }
                    case 35: {
                        int blockSize = 100;
                        int blockX = tremoloX / blockSize;
                        int blockY = tremoloY / blockSize;
                        
                        int pattern = (blockX % 2) == (blockY % 2);
                        float pulse = 0.5f + 0.5f * std::sin(t_stage * 3.0f);
                        
                        float hue = std::fmod((float)blockX / 10.0f + (float)blockY / 10.0f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);

                        if (pattern) {
                            r = GetRValue(color) * pulse;
                            g = GetGValue(color) * pulse;
                            b = GetBValue(color) * pulse;
                        } else {
                            r = g = b = 255.0f * (1.0f - pulse);
                        }
                        
                        break;
                    }
                    case 36: { 
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        
                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);
                        
                        float tunnelSpeed = t_stage * 0.5f;
                        float repeat = 100.0f;

                        float z = std::fmod(dist * repeat + tunnelSpeed, repeat);
                        
                        float hue = std::fmod(z / repeat + angle / (2.0f * M_PI), 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        float sat = 1.0f;
                        float lum = 0.5f + 0.5f * std::cos(z * M_PI * 2.0f / 5.0f); 
                        
                        DWORD color = HSLToRGB(hue, sat, lum);
                        
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);

                        float lineThickness = 0.005f;
                        if (std::fmod(z, 5.0f) < 5.0f * lineThickness) {
                            r = g = b = 255.0f;
                        }

                        break;
                    }
                    case 37: {
                        float u = (float)tremoloX / screenWidth;
                        float v = (float)tremoloY / screenHeight;

                        float waveX = std::sin(u * 20.0f + t_stage * 1.5f) * 0.05f;
                        float waveY = std::cos(v * 15.0f + t_stage * 2.0f) * 0.05f;
                        
                        float distortedU = u + waveX;
                        float distortedV = v + waveY;

                        float hue = std::fmod(distortedU * 0.5f + distortedV * 0.5f + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD color = HSLToRGB(hue, 1.0f, 0.5f);
                        r = GetRValue(color);
                        g = GetGValue(color);
                        b = GetBValue(color);
                        
                        float grid = std::fmod(distortedU * 10.0f, 1.0f);
                        grid += std::fmod(distortedV * 10.0f, 1.0f);
                        
                        if (grid < 0.05f || grid > 1.95f) {
                            r = g = b = 255.0f; 
                        }
                        
                        break;
                    }
                    case 38: {
                        float normalizedX = (float)tremoloX / screenWidth;
                        float normalizedY = (float)tremoloY / screenHeight;
                        
                        float stripe = std::fmod(normalizedX * 10.0f + t_stage * 2.0f, 1.0f);
                        float hue = std::fmod(stripe + t_stage * 0.05f, 1.0f);
                        if (hue < 0) hue += 1.0f;
                        
                        DWORD baseColor = HSLToRGB(hue, 1.0f, 0.5f + 0.5f * std::sin(normalizedY * 20.0f));
                        
                        r = GetRValue(baseColor);
                        g = GetGValue(baseColor);
                        b = GetBValue(baseColor);

                        if (std::sin(t_stage * 40.0f) > 0.8f) {
                            r = 255.0f - r;
                            g = 255.0f - g;
                            b = 255.0f - b;
                        }
                        break;
                    }
                    case 39: {
                        float deltaX = tremoloX - cx;
                        float deltaY = tremoloY - cy;
                        float dist = std::sqrt(deltaX * deltaX + deltaY * deltaY);
                        
                        float waveFreq = 0.01f;
                        float highFreq = 0.1f;
                        
                        float wave1 = std::sin(dist * waveFreq * 50.0f - t_stage * 8.0f);
                        float wave2 = std::cos(dist * highFreq * 10.0f + t_stage * 5.0f);
                        
                        float brightness = 0.5f + 0.5f * (wave1 + wave2) / 2.0f;
                        
                        float angle = std::atan2(deltaY, deltaX);
                        float hue = std::fmod(angle / (2.0f * M_PI) + t_stage * 0.1f, 1.0f);
                        if (hue < 0) hue += 1.0f;

                        DWORD color = HSLToRGB(hue, 1.0f, brightness);
                        
                        BYTE xor_val = (BYTE)(((int)(time * 20.0f) * 16) ^ (tremoloX / 10));

                        r = (float)(GetRValue(color) ^ xor_val);
                        g = (float)(GetGValue(color) ^ xor_val);
                        b = (float)(GetBValue(color) ^ xor_val);

                        break;
                    }
                    case 40: {
                        float normalizedX = (float)tremoloX / screenWidth - 0.5f;
                        float normalizedY = (float)tremoloY / screenHeight - 0.5f;
                        float t_end = t_stage; 

                        float angle = std::atan2(normalizedY, normalizedX);
                        float dist = std::sqrt(normalizedX * normalizedX + normalizedY * normalizedY);
                        float rotationSpeed = t_end * 3.0f; 
                        float rotatedAngle = angle + rotationSpeed * (0.5f + std::sin(dist * 50.0f)); 
                        float modulatedDist = dist * (1.0f + std::cos(rotatedAngle * 20.0f + t_end * 5.0f) * 0.6f);
                        
                        float sampleX = std::fmod(modulatedDist * 80.0f * std::cos(rotatedAngle), 1.0f); 
                        float sampleY = std::fmod(modulatedDist * 80.0f * std::sin(rotatedAngle), 1.0f);
                        if (sampleX < 0) sampleX += 1.0f;
                        if (sampleY < 0) sampleY += 1.0f;

                        BYTE baseR = ColorWave(sampleX * 10.0f, t_end * 10.0f, 1.0f);
                        BYTE baseG = ColorWave(sampleY * 10.0f, t_end * 9.0f, 1.0f);
                        BYTE baseB = ColorWave((sampleX + sampleY) * 5.0f, t_end * 11.0f, 1.0f);
                        
                        BYTE xor_val = (BYTE)(((int)(time * 30.0f) * 16) ^ (tremoloX * 30));

                        r = (float)(baseR ^ xor_val);
                        g = (float)(baseG ^ (xor_val / 2));
                        b = (float)(baseB ^ (xor_val * 2));

                        float fadeFactor = (t_end > 15.0f) ? (t_end - 15.0f) / 5.0f : 0.0f;
                        fadeFactor = std::min(1.0f, fadeFactor);

                        r = r * (1.0f - fadeFactor);
                        g = g * (1.0f - fadeFactor);
                        b = b * (1.0f - fadeFactor);
                        
                        if (t_end >= 20.0f) {
                            running = false;
                        }

                        break;
                    }
                    default: 
                        r = g = b = 0.0f; 
                        break;
                }

                r = std::min(255.0f, std::max(0.0f, r));
                g = std::min(255.0f, std::max(0.0f, g));
                b = std::min(255.0f, std::max(0.0f, b));
                
                // ESCRITURA DIRECTA DE PÍXEL (Pixel Manipulation)
                pixels[index] = RGB((BYTE)r, (BYTE)g, (BYTE)b); 
            }
        }

        BitBlt(hdcScreen, 0, 0, screenWidth, screenHeight, hdcMem, 0, 0, SRCCOPY);

        Sleep(30); 
    }

    PlaySoundW(NULL, NULL, 0); 
    SelectObject(hdcMem, hOldBitmap);
    DeleteObject(hDIB);
    DeleteDC(hdcMem);
    ReleaseDC(NULL, hdcScreen);
}


int WINAPI WinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, LPSTR lpCmdLine, int nCmdShow) {
    srand((unsigned int)time(NULL));

    int result = MessageBoxW(
        NULL,              
        MESSAGE_TEXT,      
        APP_TITLE,         
        MB_YESNO | MB_ICONQUESTION 
    );

    if (result == IDYES) {
        Sleep(100); 

        PlaySoundW(AUDIO_FILES[0], NULL, SND_FILENAME | SND_ASYNC | SND_NODEFAULT);
        lastPlayedAudioIndex = 0;

        RenderDesktopShader();
    }
    
    return 0;
}